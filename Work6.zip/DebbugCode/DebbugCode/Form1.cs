namespace DebbugCode
{
    public partial class Form1 : Form
    {
        int[] mass = { 22, 11, 0, 6, 12, 23, 4 };
        public Form1()
        {
            InitializeComponent();
            label2.Text = "";
            label1.Text = "�������";

            for (int i = 0; i < mass.Length; i++)
            {
                label2.Text += mass[i].ToString();
                label2.Text += " ";
            }
        }
        int F1(int n) 
        {
            int a = 30;
            a -= n;
            int i = 0;
            while (a < 40)
            {
                i++;
            }
            return i;
        }

        int deleteTwo(int a) 
        {
            return 20 / a;
        }
        bool parityNumber(int num) 
        {
            return num % 2 == 1;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            int sel = int.Parse(textBox1.Text);
            int num = mass[sel];
            num = deleteTwo(num);
            if(parityNumber(num)) 
                num = F1(num);
            else 
            {
                int a = 8;
                int b = 9;
                int c = 5;
                num = a + b + c;
            }
            label3.Text = num;
        }
    }
}
