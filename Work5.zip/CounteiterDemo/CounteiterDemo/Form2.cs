﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CounteiterDemo
{
    public partial class Form2 : Form
    {
        public Form2(string c1, string c2, string Text)
        {
            InitializeComponent();
            label1.Text = c1;
            label2.Text = c2;
            label3.Text = Text;
        }
    }
}
