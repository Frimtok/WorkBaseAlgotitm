﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsDemoListView
{
    public partial class Form1 : Form
    {
        string[] team_1 = { "Животные", "Продукты", "Праздники" };
        string[] team_2 = { "Растения", "Инструменты", "устройства" };
        List<string> team_3 = new List<string>();
        int[] numberteam = { 1, 2, 3 };
        int middle;
        public Form1()
        {
            InitializeComponent();
            comboBox1.DataSource = numberteam;
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add(txtTeam.Text);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            team_3 = team_1.Concat(team_2).ToList();
            listBox1.Items.Clear();
            if ((int)comboBox1.SelectedItem == 1)
            {
                listBox1.Items.AddRange(team_1);
                middle = team_1.Length / 2;
            }
            if ((int)comboBox1.SelectedItem == 2)
            {
                listBox1.Items.AddRange(team_2);
                middle = team_2.Length / 2;
            }
            if ((int)comboBox1.SelectedItem == 3)
            {
                foreach (string item in team_3)
                {
                    listBox1.Items.Add(item);
                }
                middle = team_3.Count / 2;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.RemoveAt(middle);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(textBox1.Text) - 1;
            if(id >= 0)
                listBox1.Items.RemoveAt(id);
        }
    }
}
