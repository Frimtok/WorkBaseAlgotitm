﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.chkApple = new System.Windows.Forms.CheckBox();
            this.chkMango = new System.Windows.Forms.CheckBox();
            this.chkMeat = new System.Windows.Forms.CheckBox();
            this.chkFish = new System.Windows.Forms.CheckBox();
            this.chkMilk = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.rbnMessage = new System.Windows.Forms.RadioButton();
            this.rbnText = new System.Windows.Forms.RadioButton();
            this.lblResult = new System.Windows.Forms.Label();
            this.btnBuy = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // chkApple
            // 
            this.chkApple.AutoSize = true;
            this.chkApple.BackColor = System.Drawing.Color.YellowGreen;
            this.chkApple.Location = new System.Drawing.Point(202, 79);
            this.chkApple.Name = "chkApple";
            this.chkApple.Size = new System.Drawing.Size(64, 17);
            this.chkApple.TabIndex = 0;
            this.chkApple.Text = "Яблоко";
            this.chkApple.UseVisualStyleBackColor = false;
            // 
            // chkMango
            // 
            this.chkMango.AutoSize = true;
            this.chkMango.BackColor = System.Drawing.SystemColors.Info;
            this.chkMango.Location = new System.Drawing.Point(202, 122);
            this.chkMango.Name = "chkMango";
            this.chkMango.Size = new System.Drawing.Size(58, 17);
            this.chkMango.TabIndex = 1;
            this.chkMango.Text = "Манго";
            this.chkMango.UseVisualStyleBackColor = false;
            // 
            // chkMeat
            // 
            this.chkMeat.AutoSize = true;
            this.chkMeat.BackColor = System.Drawing.Color.Crimson;
            this.chkMeat.Location = new System.Drawing.Point(202, 163);
            this.chkMeat.Name = "chkMeat";
            this.chkMeat.Size = new System.Drawing.Size(53, 17);
            this.chkMeat.TabIndex = 2;
            this.chkMeat.Text = "Мясо";
            this.chkMeat.UseVisualStyleBackColor = false;
            // 
            // chkFish
            // 
            this.chkFish.AutoSize = true;
            this.chkFish.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.chkFish.Location = new System.Drawing.Point(202, 200);
            this.chkFish.Name = "chkFish";
            this.chkFish.Size = new System.Drawing.Size(53, 17);
            this.chkFish.TabIndex = 3;
            this.chkFish.Text = "Рыба";
            this.chkFish.UseVisualStyleBackColor = false;
            // 
            // chkMilk
            // 
            this.chkMilk.AutoSize = true;
            this.chkMilk.BackColor = System.Drawing.SystemColors.MenuBar;
            this.chkMilk.Location = new System.Drawing.Point(202, 238);
            this.chkMilk.Name = "chkMilk";
            this.chkMilk.Size = new System.Drawing.Size(65, 17);
            this.chkMilk.TabIndex = 4;
            this.chkMilk.Text = "Молоко";
            this.chkMilk.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(143, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(185, 39);
            this.label1.TabIndex = 5;
            this.label1.Text = "Продукты";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(493, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(193, 39);
            this.label2.TabIndex = 6;
            this.label2.Text = "Результат";
            // 
            // rbnMessage
            // 
            this.rbnMessage.AutoSize = true;
            this.rbnMessage.Location = new System.Drawing.Point(448, 110);
            this.rbnMessage.Name = "rbnMessage";
            this.rbnMessage.Size = new System.Drawing.Size(91, 17);
            this.rbnMessage.TabIndex = 7;
            this.rbnMessage.TabStop = true;
            this.rbnMessage.Text = "Сообщением";
            this.rbnMessage.UseVisualStyleBackColor = true;
            // 
            // rbnText
            // 
            this.rbnText.AutoSize = true;
            this.rbnText.Location = new System.Drawing.Point(601, 110);
            this.rbnText.Name = "rbnText";
            this.rbnText.Size = new System.Drawing.Size(69, 17);
            this.rbnText.TabIndex = 8;
            this.rbnText.TabStop = true;
            this.rbnText.Text = "Текстом";
            this.rbnText.UseVisualStyleBackColor = true;
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Location = new System.Drawing.Point(598, 163);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(0, 13);
            this.lblResult.TabIndex = 9;
            // 
            // btnBuy
            // 
            this.btnBuy.BackColor = System.Drawing.Color.SkyBlue;
            this.btnBuy.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnBuy.Location = new System.Drawing.Point(601, 210);
            this.btnBuy.Name = "btnBuy";
            this.btnBuy.Size = new System.Drawing.Size(144, 55);
            this.btnBuy.TabIndex = 10;
            this.btnBuy.Text = "Купить";
            this.btnBuy.UseVisualStyleBackColor = false;
            this.btnBuy.Click += new System.EventHandler(this.btnBuy_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnBuy);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.rbnText);
            this.Controls.Add(this.rbnMessage);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.chkMilk);
            this.Controls.Add(this.chkFish);
            this.Controls.Add(this.chkMeat);
            this.Controls.Add(this.chkMango);
            this.Controls.Add(this.chkApple);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox chkApple;
        private System.Windows.Forms.CheckBox chkMango;
        private System.Windows.Forms.CheckBox chkMeat;
        private System.Windows.Forms.CheckBox chkFish;
        private System.Windows.Forms.CheckBox chkMilk;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton rbnMessage;
        private System.Windows.Forms.RadioButton rbnText;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Button btnBuy;
    }
}

