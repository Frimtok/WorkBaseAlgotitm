﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        string product = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnBuy_Click(object sender, EventArgs e)
        {
            product = "";
            if (chkApple.CheckState == CheckState.Checked)
            {
                product += chkApple.Text + " ";
            }
            if (chkMeat.CheckState == CheckState.Checked)
            {
                product += chkMeat.Text + " ";
            }
            if (chkFish.CheckState == CheckState.Checked)
            {
                product += chkFish.Text + " ";
            }
            if (chkMilk.CheckState == CheckState.Checked)
            {
                product += chkMilk.Text + " ";
            }
            if (chkMango.CheckState == CheckState.Checked)
            {
                product += chkMango.Text + " ";
            }
            if (rbnMessage.Checked)
            {
                lblResult.Text = "";
                MessageBox.Show(product);
            }
            if(rbnText.Checked) lblResult.Text = product;
        }
    }
}
