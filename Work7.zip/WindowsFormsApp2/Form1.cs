﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Writebtn_Click(object sender, EventArgs e)
        {
            Class1 person = new Class1();
            person.Name = textBox1.Text;
            person.Age = textBox2.Text;
            person.address = textBox3.Text;
            person.city = textBox4.Text;

            listBox1.Items.Clear();
            listBox1.Items.Add(person.Name);
            listBox1.Items.Add(person.Age);
            listBox1.Items.Add(person.address);
            listBox1.Items.Add(person.city);
        }
    }
}
