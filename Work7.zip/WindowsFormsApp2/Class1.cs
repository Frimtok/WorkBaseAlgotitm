﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2
{
    public class Class1
    {
        public string Name { get; set; }
        public string Age { get; set; }
        public string city { get; set; }
        public string address { get; set; }
    }
}
